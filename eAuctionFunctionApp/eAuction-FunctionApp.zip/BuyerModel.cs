﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eAuctionFunctionApp
{
    public class BuyerModel
    {
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string address { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string pin { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string bidamount { get; set; }
        public string productid { get; set; }
    }
}
